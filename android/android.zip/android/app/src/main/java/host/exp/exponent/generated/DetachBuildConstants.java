package host.exp.exponent.generated;

// This file is auto-generated. Please don't rename!
public class DetachBuildConstants {

  public static final String DEVELOPMENT_URL = "expef8ad74c1b274315b78bc9e54d989b5f://192.168.0.102:19000";

}
